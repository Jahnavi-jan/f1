﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SchoolDemo
{
    public class School
    {
        int rollNumber;
        string studentName;
        byte age;
        char gender;
        DateTime dateOfBirth;
        string address;
        float percentage;
        public void SetData()
        {
            Console.Write("Enter Student Roll Number : ");
            rollNumber = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter Student Name : ");
            studentName = Convert.ToString(Console.ReadLine());
            Console.Write("Enter Student Age : ");
            age = Convert.ToByte(Console.ReadLine());
            Console.Write("Enter Student Gender : ");
            gender = Convert.ToChar(Console.ReadLine());
            Console.Write("Enter Student Date of Birth : ");
            dateOfBirth = Convert.ToDateTime(Console.ReadLine());
            Console.Write("Enter Student Address : ");
            address = Convert.ToString(Console.ReadLine());
            Console.Write("Enter Student Percentage : ");
            percentage = Convert.ToSingle(Console.ReadLine());
        }
        public void GetData()
        {
            Console.WriteLine("Student Roll Number is : " + rollNumber);
            Console.WriteLine("Student Name is : " + studentName);
            Console.WriteLine("Student Age is : " + age);
            Console.WriteLine("Student Gender is : " + gender);
            Console.WriteLine("Student Date of Birth is : " + dateOfBirth);
            Console.WriteLine("Student Address is : " + address);
            Console.WriteLine("Student Percentage is : " + percentage);
        }
    }
}
