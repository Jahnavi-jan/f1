﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SchoolDemo;

namespace SchoolData
{
    class Program
    {
        static void Main(string[] args)
        {
            School[] s = new School[10];
            for(int i=0;i<10;i++)
            {
                s[i] = new School();
            }
            for(int i=0;i<10;i++)
            {
                s[i].SetData();
            }
            for(int i=0;i<10;i++)
            {
                s[i].GetData();
            }
            Console.ReadKey();
        }
    }
}
